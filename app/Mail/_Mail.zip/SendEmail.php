<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $na;
    public $em;
    public $ph;
    public $mes;
	public $c;
	public $su;
	public $crt;
	public $addr;
    public function __construct($name,$email,$phone,$message,$cv,$sub,$cart,$address)
    {
        $this->mes = $message;
        $this->em = $email;
        $this->ph = $phone;
        $this->na = $name;
		$this->c = $cv;
		$this->su = $sub;
		$this->crt = $cart;
		$this->addr = $address;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $e_message = $this->mes;
        $e_email = $this->em;
        $e_phone = $this->ph;
        $e_name = $this->na;
		$e_c = $this->c;
		$e_su = $this->su;
		$e_crt = $this->crt;
		$e_addr = $this->addr;
        return $this->view('email.contact',compact('e_message','e_email','e_phone','e_name','e_c','e_crt','e_addr'))->subject($e_su);
    }
}
